```
// .then(() => {
  //   alert("user is now logged in, user: " + this.state.user.userName);
  //   const user = { ...this.state.user };
  //   user.isLogin = true;
  //   this.setState({ user });
  //   this.props.history.push("/");
  //   // console.log("isLogin: " + request.session.isLogin);
  // })

  // .then(user => {
  //   this.props.history.push("/vacations"); // Redirect to "/products" route.
```
